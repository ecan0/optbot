# Optbot quantitative-results package

Contents:

- `slack-summary.md`: shareable aggregate quantitative findings.

Privacy boundary:

- Contains aggregate quantitative results only.
- Does not contain response identifiers, participant-level data, raw interview answers, restricted free text, cloud locations, or credentials.

Method:

- Final snapshot: 30 valid paired responses; zero quality/exclusion rows.
- Ratings: integer 1–5 scales for willingness, trust, completeness, and ease of use.
- Paired effect: visual rating minus plain-text rating.
- Intervals: 95% percentile bootstrap intervals for the mean paired difference, using 100,000 deterministic resamples.
- Exact sign-test values are secondary descriptive inferential summaries.

Do not append restricted interview answers to this package or upload them to Slack.
