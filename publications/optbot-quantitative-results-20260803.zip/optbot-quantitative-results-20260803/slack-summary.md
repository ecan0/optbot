# Optbot notice study — quantitative results

**Copy/paste for Slack**

We analyzed the final snapshot of **30 valid paired responses**. The visual and plain-text notice were each rated by every participant on 1–5 scales. There were **no quality/exclusion rows**, no duplicate responses, and no missing paired ratings.

## Primary outcome: willingness to share

- Visual mean: **3.40 / 5**
- Plain-text mean: **3.20 / 5**
- Mean paired difference (visual − text): **+0.20**
- 95% bootstrap interval: **−0.07 to +0.50**
- Median paired difference: **0**
- Visual higher / lower / tied: **9 / 5 / 16**
- Secondary exact sign-test p: **0.424**

**Interpretation:** willingness was slightly higher for the visual notice in this sample, but the uncertainty interval includes zero. This is not compelling evidence of a reliable willingness difference.

## Exploratory outcomes

| Outcome | Visual mean | Plain-text mean | Mean paired difference | 95% bootstrap interval |
| --- | ---: | ---: | ---: | ---: |
| Trust | 3.37 | 3.10 | +0.27 | −0.03 to +0.60 |
| Completeness | 3.70 | 3.90 | −0.20 | −0.53 to +0.13 |
| Ease of use | 4.27 | 3.97 | +0.30 | −0.07 to +0.67 |

These outcomes were exploratory. No multiple-comparison claim is made.

## Order and preference

- Visual notice first: **17** participants
- Plain-text notice first: **13** participants
- Preferred visual presentation: **19 / 30 (63.3%)**
- Preferred plain-text presentation: **11 / 30 (36.7%)**

## Scope and limits

This was a within-participant comparison of a fixed visual treatment and the same notice in plain text. Presentation order was randomized, but the study does not provide a between-treatment causal contrast. Results are limited to this simulated notice context and this sample size.

No participant-level data, interview answers, or restricted free text is included in this package.
